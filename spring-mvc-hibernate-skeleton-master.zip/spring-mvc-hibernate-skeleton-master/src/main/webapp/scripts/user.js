document.observe('dom:loaded', function() {
	RowSelector.bindEvents();
});
